import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import nodemailer from 'nodemailer';

// Import our new route files
import contentRoutes from './routes/content.js';
import trackerRoutes from './routes/tracker.js';

// Load secret variables
dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;

// Setup paths to serve frontend files
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Middleware
app.use(cors());
app.use(express.json());

// Tell Express to serve the static frontend files from the "public" folder
app.use(express.static(path.join(__dirname, 'public')));

// Connect the route files to specific URLs
app.use('/api/content', contentRoutes);
app.use('/api/tracker', trackerRoutes);

let transporter = null;

if (process.env.EMAIL_USER && process.env.EMAIL_PASS) {
    transporter = nodemailer.createTransport({
        service: process.env.EMAIL_SERVICE || 'gmail',
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });
} else {
    console.warn('Email service is not configured. Set EMAIL_USER and EMAIL_PASS in your .env file to enable sending.');
}

app.post('/api/send-email', async (req, res) => {
    const { recipient, message, subject } = req.body;

    if (!recipient) {
        return res.status(400).json({ success: false, error: 'Recipient email is required.' });
    }

    if (!message) {
        return res.status(400).json({ success: false, error: 'Email message is required.' });
    }

    if (!transporter) {
        return res.status(500).json({
            success: false,
            error: 'Email service is not configured. Add EMAIL_USER and EMAIL_PASS to your .env file and restart the server.'
        });
    }

    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: recipient,
        subject: subject || 'Your DayLy Content Studio Draft 🚀',
        text: message
    };

    try {
        await transporter.sendMail(mailOptions);
        res.status(200).json({ success: true, message: 'Email sent successfully!' });
    } catch (error) {
        console.error('Email sending error:', error);
        res.status(500).json({ success: false, error: error.message || 'Failed to send email.' });
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`🚀 DayLy server is running on http://localhost:${PORT}`);
});